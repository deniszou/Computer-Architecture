#include<stdio.h>
#include<stdlib.h>
int main(int argc, char *argv[]){
  if(argc != 2){
    printf("insufficient args\n");
    return 0;
  }
  FILE *input = fopen(argv[1], "r");
  if(input == 0){
		printf("error\n");
		return 0;
  }
  int size,i, j, k, rowsum, colsum, diagsum, sum = 0;
  int check[1000];
  int array[100][100];
  fscanf(input, "%d", &size);
  for(i = 0; i < size; i++){
    for(j = 0; j < size; j++){
      fscanf(input, "%d", &array[i][j]);
      if(check[array[i][j]] == 1){
        printf("not-magic\n");
        return 0;
      }else{
        check[array[i][j]] = 1;
      }
      if(array[i][j] > (size*size)){
        printf("not-magic\n");
        return 0;
      }
    }
    fscanf(input,"\n");
  }
  /*for(i = 0; i < size; i++){
    for(j = 0; j < size; j++){
      printf("%d",array[i][j]);
    }
  }*/
  for(i = 0; i < size; i++){
    rowsum = 0;
    colsum = 0;
    diagsum = 0;
    for(j = 0; j < size; j++){
      rowsum = rowsum + array[i][j];
      colsum = colsum + array[j][i];
      diagsum = diagsum + array[j][j];
    }
    if((diagsum != rowsum)||(rowsum!=colsum)){
      printf("not-magic\n");
      return 0;
    }
  }
  printf("magic\n");
  fclose(input);
  return 0;
}
