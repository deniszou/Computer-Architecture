#include<stdio.h>
#include<stdlib.h>
int partition(int arr[], int left, int rite){
  //int ppos = (rite)/2;
  int pivot = arr[rite];
  //arr[left] = arr[rite];
  //arr[rite] = pivot;
  int swap = left-1;
  int step = left;
  //if(arr[swap] < pivot && arr[swap] < rite){
    //swap++;
  //}
  for(;step <= rite-1; step++){
    if(arr[step] <= pivot){
      swap++;
      int temp = arr[step];
      arr[step] = arr[swap];
      arr[swap] = temp;
    }
  }
  int temp = arr[swap+1];
  arr[swap+1] = arr[rite];
  arr[rite] = temp;
  return swap+1;
}
void quickSort(int arr[], int left, int rite){
  if(left < rite){
    int swap = partition(arr, left, rite);
    quickSort(arr, left, swap-1);
    quickSort(arr, swap+1, rite);
  }
}
int *doubleSort(int arr[], int n){
        //int * arr;
  //arr = (int**) malloc(n * sizeof(int*));
  int k = 0;
  int i = 0;
  int temp = 0;
  int j = 0;
  //int t = 0;
  for (; i < n; i++){ //separate evens
    if((arr[i])%2 == 0){
      temp = arr[j];
      arr[j] = arr[i];
      arr[i] = temp;
      j++;
      k++; //next to switch
    }
  }
  //quickSort(arr, 0, n-1);
  quickSort(arr, 0, k-1);
  /*int j = 0;
  for (; j < n; j++){ //make evens positive
    if((arr[j])%2 == 0){
      (arr[j]) *= -1;
    }
  }*/
  quickSort(arr, k, n-1);
  //printf("%d\n", k);
  return arr;
}
int main(int argc, char* argv[]){
  int asize;
  if(argc != 2){
    printf("insufficient arguments\n");
    return 0;
  }
  FILE * input = fopen(argv[1], "r");
  if(input == NULL){
    printf("input file empty\n");
    return 0;
  }
  fscanf(input, "%d\n", &asize);
  int arr[asize];
  //arr[asize] = (int*) malloc(asize * sizeof(int));

  int i = 0;
  for(; i < asize; i++){
    fscanf(input, "%d", &arr[i]);
    //printf("%d\t", arr[i]);
  }

  int * arry  = (doubleSort(arr, asize));
  //printf("%s\n", argv[1]);
  int j = 0;
  for(; j < asize-1; j++){
    printf("%d\t", arry[j]);
  }
  printf("%d\n", arry[j]);
  fclose(input);
  return 0;
}
