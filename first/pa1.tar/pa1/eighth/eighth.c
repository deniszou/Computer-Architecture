#include<stdio.h>
#include<stdlib.h>
struct node {
	int data;
	struct node *right;
	struct node *left;
};

struct node *min(struct node *root);

void insert(int dat, struct node **current, int height) {
	if (*current != NULL) {
    if ((*current)->data == dat) {
  		printf("duplicate\n");
  		return;
  	}
  	else if ((*current)->data < dat) {
  		return insert(dat, &(*current)->right, height+1);
  	}
  	else if ((*current)->data > dat) {
  		return insert(dat, &(*current)->left, height+1);
  	}
	}else if(*current == NULL){
    struct node *temp = malloc(sizeof(struct node));
    temp->left = NULL;
    temp->right = NULL;
    temp->data = dat;
    printf("inserted %d\n", height);
    *current = temp;
    return;
  }
	return;
}

void *search(int dat, struct node *current) {
	int height = 1;
	while (current != NULL) {
	   if (current->data < dat) {
			current = current->right;
			height++;
		}else if (current->data == dat) {
			printf("present %d\n", height);
			return 0;
		}else {
			current = current->left;
			height++;
		}
	}
	printf("absent\n");
	return 0;
}
struct node *delete(struct node *root, int num) {
	if (root == NULL) {
		printf("fail\n");
		return root;
	}
	if (num < root->data) { //traverse tree
		root->left = delete(root->left, num);
	}
	else if (num > root->data) {
		root->right = delete(root->right, num);
	}
	else { //found node to be deleted
		if (root->left == NULL && root->right == NULL) { //no children
			free(root);
			printf("success\n");
			return NULL;
		}
		else if (root->left == NULL) {
			root=root->right;
			printf("success\n");
			return root;
		}
		else if (root->right == NULL) {
			root=root->left;
			printf("success\n");
			return root;
		}
		else { //two children
			root = root->right;
			while (root->left != NULL) {
				root = root->left;
			}
			struct node *nuevo = root;
			root->data = nuevo->data;
			root->right = delete(root->right, nuevo->data);
		}
	}
	return root;
}
int main(int argc, char *argv[]) {
	if (argc < 2 ) {
		printf("error\n");
		return 0;
	}

	FILE *fp = fopen(argv[1], "r");
	int dat;
	char act;

	struct node *root = NULL;
	struct node **tempRoot = &root;

	while (fscanf(fp, "%c %d\n", &act, &dat) == 2) {
		if (act == 'i') {
			insert(dat, tempRoot, 1);
		}

		if (act == 's') {
			search(dat, root);
		}

		if (act == 'd') {
			root = delete(root, dat);
		}
		else if(act !='d' && act != 'i' && act != 's'){
			printf("error\n");
		}
	}
	fclose(fp);
	return 0;
}
