#include<stdio.h>
#include<stdlib.h>
int main(int argc, char *argv[]){
  if(argc != 2){
    printf("insufficient args\n");
    return 0;
  }
  FILE *input = fopen(argv[1], "r");
  if(input == 0){
		printf("error\n");
		return 0;
  }
  int rows1, columns1, rows2, columns2;
  int matrix1[50][50];
  int matrix2[50][50];
  int fmatrix[50][50];
  //matrix1 = (int**)malloc(rows1*sizeof(int*));
  int i, j = 0;
  fscanf(input, "%d %d", &rows1, &columns1);
  for(i = 0; i < rows1; i++){
    //matrix1[i] = (int*)malloc(columns1*sizeof(int));
    for(j = 0; j < columns1; j++){
      fscanf(input, "%d", &matrix1[i][j]);
    }
    fscanf(input, "\n");
  }
  //matrix2 = (int**)malloc(rows2*sizeof(int*));
  fscanf(input, "%d %d", &rows2, &columns2);
  for(i = 0; i < rows2; i++){
  //  matrix2[i] = (int*)malloc(columns2*sizeof(int));
    for(j = 0; j < columns2; j++){
      fscanf(input, "%d", &matrix2[i][j]);
    }
    fscanf(input, "\n");
  }
  if(columns1 != rows2){
    printf("bad-matrices\n");
    return 0;
  }
  int k, product = 0;
  //fmatrix = (int**)malloc(rows1*sizeof(int*));
  for(i = 0; i < rows1; i++){
  //  fmatrix[i] = (int*)malloc(columns2*sizeof(int));
    for (j = 0; j < columns2; j++) {
      for (k = 0; k < columns1; k++){
        product = product + matrix1[i][k]*matrix2[k][j];
      }
      fmatrix[i][j] = product;
      product = 0;
    }
  }
  for (i = 0; i < rows1; i++) {
    for(j = 0; j< columns2; j++){
      printf("%d\t", fmatrix[i][j]);
    }
    printf("\n");
  }
  return 0;
}
