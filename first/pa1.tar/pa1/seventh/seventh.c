#include<stdio.h>
#include<stdlib.h>
#include<string.h>
int main(int argc, char *argv[]) {
	if (argc <= 2) {
		printf("error\n");
		return 0;
  }
  char *str;
  int i, length, j = 0;
  for (i = 1; i < argc; i++) {
    str = argv[i];
    length = strlen(str);
    printf("%c", str[length-1]);
  }
  printf("\n");
return 0;
}
