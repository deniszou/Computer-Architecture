#include<stdio.h>
#include<stdlib.h>
struct Node{
  int data;
  struct Node *next;
};
void insert(struct Node *head, int dat){
  if(head == NULL){
    head = malloc(sizeof(struct Node));
    head->data = dat;
    head->next = NULL;
    return;
  }
  struct Node *insAf = malloc(sizeof(struct Node));
  insAf->data = dat;
  struct Node *temp = head;
  struct Node *pretemp = head;
  if(head->data>dat){
    insAf->next = head;
    head = insAf;
    return;
  }
  while(temp != NULL){
    if(temp->data == dat){
      return;
    }else if (temp->data > dat){
      pretemp->next = insAf;
      insAf->next = temp;
      return;
    }
    pretemp = temp;
    temp = temp->next;
  }
  insAf->next = NULL;
  pretemp->next = insAf;
}
void delete(struct Node *head, int dat){
  struct Node *temp = head;
  struct Node *pretemp = head;
  if(head == NULL){
    return;
  }
  if(head->data == dat){
    head = head->next;
    return;
  }
  while(temp != NULL){
    if(temp->data == dat){
      pretemp->next = temp->next;
      return;
    }
    pretemp = temp;
    temp = temp->next;
  }
  return;
}
int main(int argc, char* argv[]){
  if(argc != 2){
    printf("insuff args\n");
    return 0;
  }
  FILE *input = fopen(argv[1], "r");
  if (input == NULL){
    printf("error\n");
    return 0;
  }
  int c = fgetc(input);
  if (c == EOF){
    printf("0\n");
    return 0;
  }
  char doo;
  int dat;
  //fscanf(input, "%c\n", &doo);
  //printf("%c\n", doo);
  struct Node *head;
  head = malloc(sizeof(struct Node));
  head->next = NULL;
  while(fscanf(input, "%c\t%d\n", &doo, &dat) == 2){
    //printf("%c  %d\n", doo, dat);
    if(doo == 'd'){
      delete(head, dat);
    }
    if(doo == 'i'){
      insert(head, dat);
    }
    /*}else *//*if (doo != 'i' && dat != 'd'){
      printf("no command\n");
      return 0;*/
  //  }
  }
  fclose(input);
  head = head->next;
  struct Node *counter = head;
	int count = 0;

	while (counter != NULL) {
		counter = counter->next;
		count++;
	}
	printf("%d\n", count);
  while(head != NULL){
    printf("%d\t", head->data);
    head = head->next;
  }
  printf("\n");
  /*if(!feof(input)){
    printf("file empty\n");
    return 0;
  }*/
  free(head);
  return 0;
}
